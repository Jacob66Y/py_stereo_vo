from __future__ import annotations

from typing import Dict, Iterable, List

import numpy as np

from vo.types import Keyframe, Landmark


class MapManager:
    def __init__(self) -> None:
        self.landmarks: Dict[int, Landmark] = {}
        self.keyframes: List[Keyframe] = []
        self._next_landmark_id = 0

    def add_landmarks(
        self,
        points_w: np.ndarray,
        colors_rgb: np.ndarray,
        frame_idx: int,
    ) -> list[int]:
        ids = []
        for p_w, color in zip(points_w, colors_rgb):
            lid = self._next_landmark_id
            self._next_landmark_id += 1
            self.landmarks[lid] = Landmark(
                landmark_id=lid,
                position_w=p_w.copy(),
                color_rgb=color.copy(),
                first_seen_idx=frame_idx,
                last_seen_idx=frame_idx,
            )
            ids.append(lid)
        return ids

    def update_observations(self, landmark_ids: Iterable[int], frame_idx: int) -> None:
        for lid in landmark_ids:
            if lid in self.landmarks:
                self.landmarks[lid].observations += 1
                self.landmarks[lid].last_seen_idx = frame_idx

    def get_points_from_ids(self, landmark_ids: list[int]) -> np.ndarray:
        pts = []
        for lid in landmark_ids:
            lm = self.landmarks.get(lid)
            if lm is not None and lm.active:
                pts.append(lm.position_w)
        if len(pts) == 0:
            return np.zeros((0, 3), dtype=np.float64)
        return np.asarray(pts, dtype=np.float64)

    def deactivate_stale_landmarks(self, current_frame_idx: int, max_age: int = 20) -> None:
        for lm in self.landmarks.values():
            if lm.active and (current_frame_idx - lm.last_seen_idx) > max_age:
                lm.active = False

    def add_keyframe(self, keyframe: Keyframe) -> None:
        self.keyframes.append(keyframe)
