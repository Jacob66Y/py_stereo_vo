from __future__ import annotations

import numpy as np

from vo.geometry.transforms import invert_pose, rotation_angle_deg


class KeyframeManager:
    def __init__(
        self,
        min_tracked_landmarks: int,
        translation_thresh: float,
        rotation_thresh_deg: float,
        frame_gap: int,
    ) -> None:
        self.min_tracked_landmarks = min_tracked_landmarks
        self.translation_thresh = translation_thresh
        self.rotation_thresh_deg = rotation_thresh_deg
        self.frame_gap = frame_gap

    def should_create(
        self,
        frame_idx: int,
        tracked_count: int,
        current_pose_wc: np.ndarray,
        last_keyframe_pose_wc: np.ndarray,
        last_keyframe_idx: int,
    ) -> bool:
        if tracked_count < self.min_tracked_landmarks:
            return True

        if frame_idx - last_keyframe_idx < self.frame_gap:
            return False

        delta = invert_pose(last_keyframe_pose_wc) @ current_pose_wc
        t_norm = np.linalg.norm(delta[:3, 3])
        angle = rotation_angle_deg(delta[:3, :3])

        return (t_norm >= self.translation_thresh) or (angle >= self.rotation_thresh_deg)
