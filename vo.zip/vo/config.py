from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


import os
import yaml


@dataclass
class DatasetConfig:
    root: str
    sequence: str
    input_mode: str  # "rgb" or "gray_test"


@dataclass
class TrackerConfig:
    max_frames: Optional[int]
    max_corners: int
    quality_level: float
    min_distance: int
    block_size: int
    lk_win_size: int
    lk_max_level: int
    lk_max_error: float


@dataclass
class StereoConfig:
    min_disparity: int
    num_disparities: int
    block_size: int
    min_depth: float
    max_depth: float
    min_valid_disparity: float


@dataclass
class PnPConfig:
    min_points: int
    reprojection_error: float
    confidence: float
    iterations: int


@dataclass
class KeyframeConfig:
    min_tracked_landmarks: int
    translation_thresh: float
    rotation_thresh_deg: float
    frame_gap: int
    new_feature_mask_radius: int
    max_new_landmarks: int


@dataclass
class OutputConfig:
    save_dir: str
    save_keyframes: bool
    save_trajectory: bool
    show_plot: bool
    live_view: bool


@dataclass
class VOConfig:
    dataset: DatasetConfig
    tracker: TrackerConfig
    stereo: StereoConfig
    pnp: PnPConfig
    keyframe: KeyframeConfig
    output: OutputConfig


def load_config(path: str) -> VOConfig:
    with open(path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    dataset = DatasetConfig(
        root=os.path.expanduser(raw["dataset"]["root"]),
        sequence=str(raw["dataset"]["sequence"]),
        input_mode=str(raw["dataset"]["input_mode"]),
    )

    tracker = TrackerConfig(
        max_frames=raw["tracker"]["max_frames"],
        max_corners=int(raw["tracker"]["max_corners"]),
        quality_level=float(raw["tracker"]["quality_level"]),
        min_distance=int(raw["tracker"]["min_distance"]),
        block_size=int(raw["tracker"]["block_size"]),
        lk_win_size=int(raw["tracker"]["lk_win_size"]),
        lk_max_level=int(raw["tracker"]["lk_max_level"]),
        lk_max_error=float(raw["tracker"]["lk_max_error"]),
    )

    stereo = StereoConfig(
        min_disparity=int(raw["stereo"]["min_disparity"]),
        num_disparities=int(raw["stereo"]["num_disparities"]),
        block_size=int(raw["stereo"]["block_size"]),
        min_depth=float(raw["stereo"]["min_depth"]),
        max_depth=float(raw["stereo"]["max_depth"]),
        min_valid_disparity=float(raw["stereo"]["min_valid_disparity"]),
    )

    pnp = PnPConfig(
        min_points=int(raw["pnp"]["min_points"]),
        reprojection_error=float(raw["pnp"]["reprojection_error"]),
        confidence=float(raw["pnp"]["confidence"]),
        iterations=int(raw["pnp"]["iterations"]),
    )

    keyframe = KeyframeConfig(
        min_tracked_landmarks=int(raw["keyframe"]["min_tracked_landmarks"]),
        translation_thresh=float(raw["keyframe"]["translation_thresh"]),
        rotation_thresh_deg=float(raw["keyframe"]["rotation_thresh_deg"]),
        frame_gap=int(raw["keyframe"]["frame_gap"]),
        new_feature_mask_radius=int(raw["keyframe"]["new_feature_mask_radius"]),
        max_new_landmarks=int(raw["keyframe"]["max_new_landmarks"]),
    )

    output = OutputConfig(
    save_dir=str(raw["output"]["save_dir"]),
    save_keyframes=bool(raw["output"]["save_keyframes"]),
    save_trajectory=bool(raw["output"]["save_trajectory"]),
    show_plot=bool(raw["output"]["show_plot"]),
    live_view=bool(raw["output"]["live_view"]),
    )

    return VOConfig(
        dataset=dataset,
        tracker=tracker,
        stereo=stereo,
        pnp=pnp,
        keyframe=keyframe,
        output=output,
    )
