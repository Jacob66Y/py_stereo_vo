from __future__ import annotations

import os
from typing import Optional

import cv2
import numpy as np
import pandas as pd

from vo.dataset.base import BaseStereoDataset
from vo.dataset.image_utils import bgr_to_rgb, gray_to_rgb
from vo.types import StereoFrame


class KITTIStereoDataset(BaseStereoDataset):
    def __init__(self, root: str, sequence: str, input_mode: str = "rgb") -> None:
        self.root = os.path.expanduser(root)
        self.sequence = sequence
        self.input_mode = input_mode

        self.seq_dir = os.path.join(self.root, "sequences", sequence)
        self.pose_path = os.path.join(self.root, "poses", f"{sequence}.txt")

        if input_mode == "rgb":
            self.left_dir = os.path.join(self.seq_dir, "image_2")
            self.right_dir = os.path.join(self.seq_dir, "image_3")
            self.active_left_key = "P2:"
            self.active_right_key = "P3:"
            self.read_flag = cv2.IMREAD_COLOR
        elif input_mode == "gray_test":
            self.left_dir = os.path.join(self.seq_dir, "image_0")
            self.right_dir = os.path.join(self.seq_dir, "image_1")
            print(self.right_dir)
            self.active_left_key = "P0:"
            self.active_right_key = "P1:"
            self.read_flag = cv2.IMREAD_GRAYSCALE
        else:
            raise ValueError("input_mode must be 'rgb' or 'gray_test'")

        if not os.path.isdir(self.left_dir) or not os.path.isdir(self.right_dir):
            raise FileNotFoundError("KITTI image folders not found for selected mode")

        self.left_files = self._sorted_files(self.left_dir)
        self.right_files = self._sorted_files(self.right_dir)

        if len(self.left_files) != len(self.right_files):
            raise RuntimeError("Left/right image counts do not match")

        self.num_frames = len(self.left_files)

        calib_path = os.path.join(self.seq_dir, "calib.txt")
        calib = pd.read_csv(calib_path, delimiter=" ", header=None, index_col=0)
        self._P_left = np.array(calib.loc[self.active_left_key]).reshape((3, 4)).astype(np.float64)
        self._P_right = np.array(calib.loc[self.active_right_key]).reshape((3, 4)).astype(np.float64)

        times_path = os.path.join(self.seq_dir, "times.txt")
        self.times = np.array(pd.read_csv(times_path, delimiter=" ", header=None)).reshape(-1)

        self._gt: Optional[np.ndarray] = None
        if os.path.isfile(self.pose_path):
            poses = pd.read_csv(self.pose_path, delimiter=" ", header=None)
            self._gt = np.zeros((len(poses), 3, 4), dtype=np.float64)
            for i in range(len(poses)):
                self._gt[i] = np.array(poses.iloc[i]).reshape((3, 4))

    @staticmethod
    def _sorted_files(folder: str) -> list[str]:
        files = [f for f in os.listdir(folder) if f.endswith(".png")]
        return sorted(files, key=lambda x: int(os.path.splitext(x)[0]))

    def __len__(self) -> int:
        return self.num_frames

    @property
    def P_left(self) -> np.ndarray:
        return self._P_left

    @property
    def P_right(self) -> np.ndarray:
        return self._P_right

    @property
    def gt(self) -> Optional[np.ndarray]:
        return self._gt

    def _read_raw(self, path: str) -> np.ndarray:
        img = cv2.imread(path, self.read_flag)
        if img is None:
            raise RuntimeError(f"Failed to read image: {path}")
        return img

    def get_frame(self, idx: int) -> StereoFrame:
        if idx < 0 or idx >= self.num_frames:
            raise IndexError(f"Frame index out of range: {idx}")

        left_path = os.path.join(self.left_dir, self.left_files[idx])
        right_path = os.path.join(self.right_dir, self.right_files[idx])

        left_raw = self._read_raw(left_path)
        right_raw = self._read_raw(right_path)

        if self.input_mode == "rgb":
            # cv2.imread gives BGR, convert to RGB for the rest of the system
            left_rgb = bgr_to_rgb(left_raw)
            right_rgb = bgr_to_rgb(right_raw)
            left_gray = cv2.cvtColor(left_raw, cv2.COLOR_BGR2GRAY)
            right_gray = cv2.cvtColor(right_raw, cv2.COLOR_BGR2GRAY)
        else:
            left_gray = left_raw
            right_gray = right_raw
            left_rgb = gray_to_rgb(left_gray)
            right_rgb = gray_to_rgb(right_gray)

        return StereoFrame(
            idx=idx,
            timestamp=float(self.times[idx]),
            left_raw=left_raw,
            right_raw=right_raw,
            left_gray=left_gray,
            right_gray=right_gray,
            left_rgb=left_rgb,
            right_rgb=right_rgb,
        )
