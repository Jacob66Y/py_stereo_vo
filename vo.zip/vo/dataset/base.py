from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

import numpy as np

from vo.types import StereoFrame


class BaseStereoDataset(ABC):
    @abstractmethod
    def __len__(self) -> int:
        raise NotImplementedError

    @abstractmethod
    def get_frame(self, idx: int) -> StereoFrame:
        raise NotImplementedError

    @property
    @abstractmethod
    def P_left(self) -> np.ndarray:
        raise NotImplementedError

    @property
    @abstractmethod
    def P_right(self) -> np.ndarray:
        raise NotImplementedError

    @property
    @abstractmethod
    def gt(self) -> Optional[np.ndarray]:
        raise NotImplementedError
