import cv2
import numpy as np


def load_image(path: str, grayscale: bool = False) -> np.ndarray:
    """
    Load an image from disk.

    Args:
        path: path to image file
        grayscale: if True load as grayscale

    Returns:
        image as numpy array
    """

    if grayscale:
        img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    else:
        img = cv2.imread(path, cv2.IMREAD_COLOR)

    if img is None:
        raise RuntimeError(f"Failed to load image: {path}")

    return img


def bgr_to_rgb(image: np.ndarray) -> np.ndarray:
    """
    Convert OpenCV BGR image to RGB.
    """
    return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)


def gray_to_rgb(gray: np.ndarray) -> np.ndarray:
    """
    Convert grayscale image to RGB.
    """
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
