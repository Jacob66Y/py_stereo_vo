from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple

import cv2
import numpy as np
from scipy.optimize import least_squares


@dataclass
class BAObservation:
    keyframe_id: int
    landmark_id: int
    uv: np.ndarray  # shape (2,)


class LocalBundleAdjuster:
    def __init__(
        self,
        cam,
        window_size: int = 5,
        max_nfev: int = 30,
        huber_delta: float = 5.0,
        verbose: bool = False,
    ):
        self.cam = cam
        self.window_size = window_size
        self.max_nfev = max_nfev
        self.huber_delta = huber_delta
        self.verbose = verbose

    def optimize(self, map_manager) -> bool:
        if len(map_manager.keyframes) < 2:
            return False

        local_keyframes = map_manager.keyframes[-self.window_size:]
        if len(local_keyframes) < 2:
            return False

        observations = self._collect_observations(local_keyframes, map_manager.landmarks)
        if len(observations) < 10:
            return False

        kf_ids, lm_ids = self._collect_unique_ids(observations)
        if len(kf_ids) < 2 or len(lm_ids) < 5:
            return False

        anchor_kf_id = kf_ids[0]
        opt_kf_ids = kf_ids[1:]

        x0 = self._pack_parameters(
            local_keyframes=local_keyframes,
            landmarks=map_manager.landmarks,
            opt_kf_ids=opt_kf_ids,
            lm_ids=lm_ids,
        )

        if x0.size == 0:
            return False

        result = least_squares(
            fun=self._residuals,
            x0=x0,
            loss="huber",
            f_scale=self.huber_delta,
            max_nfev=self.max_nfev,
            verbose=2 if self.verbose else 0,
            args=(
                observations,
                local_keyframes,
                map_manager.landmarks,
                anchor_kf_id,
                opt_kf_ids,
                lm_ids,
            ),
        )

        if not result.success and not np.isfinite(result.cost):
            return False

        self._unpack_to_map(
            result.x,
            local_keyframes,
            map_manager.landmarks,
            anchor_kf_id,
            opt_kf_ids,
            lm_ids,
        )
        return True

    def _collect_observations(self, keyframes, landmarks) -> List[BAObservation]:
        obs = []

        for kf in keyframes:
            pts = np.asarray(kf.tracked_uv, dtype=np.float64)
            lm_ids = np.asarray(kf.landmark_ids)

            if len(pts) == 0 or len(lm_ids) == 0:
                continue

            n = min(len(pts), len(lm_ids))
            pts = pts[:n]
            lm_ids = lm_ids[:n]

            for uv, lm_id in zip(pts, lm_ids):
                if lm_id is None:
                    continue
                lm_id = int(lm_id)
                if lm_id not in landmarks:
                    continue
                lm = landmarks[lm_id]
                if not lm.active:
                    continue

                obs.append(
                    BAObservation(
                        keyframe_id=int(kf.frame_idx),
                        landmark_id=lm_id,
                        uv=np.asarray(uv, dtype=np.float64).reshape(2),
                    )
                )

        return obs

    def _collect_unique_ids(self, observations) -> Tuple[List[int], List[int]]:
        kf_ids = sorted({o.keyframe_id for o in observations})
        lm_ids = sorted({o.landmark_id for o in observations})
        return list(kf_ids), list(lm_ids)

    def _pack_parameters(self, local_keyframes, landmarks, opt_kf_ids, lm_ids) -> np.ndarray:
        parts = []
        kf_lookup = {int(kf.frame_idx): kf for kf in local_keyframes}

        for kf_id in opt_kf_ids:
            kf = kf_lookup[kf_id]
            T_wc = np.asarray(kf.pose_wc, dtype=np.float64)
            T_cw = np.linalg.inv(T_wc)
            R_cw = T_cw[:3, :3]
            t_cw = T_cw[:3, 3]
            rvec, _ = cv2.Rodrigues(R_cw)
            parts.append(rvec.reshape(3))
            parts.append(t_cw.reshape(3))

        for lm_id in lm_ids:
            lm = landmarks[lm_id]
            parts.append(np.asarray(lm.position_w, dtype=np.float64).reshape(3))

        if len(parts) == 0:
            return np.array([], dtype=np.float64)

        return np.concatenate(parts, axis=0)

    def _decode_parameters(
        self,
        x,
        local_keyframes,
        landmarks,
        anchor_kf_id,
        opt_kf_ids,
        lm_ids,
    ):
        pose_dict = {}
        point_dict = {}

        kf_lookup = {int(kf.frame_idx): kf for kf in local_keyframes}
        offset = 0

        anchor_kf = kf_lookup[anchor_kf_id]
        pose_dict[anchor_kf_id] = np.linalg.inv(np.asarray(anchor_kf.pose_wc, dtype=np.float64))

        for kf_id in opt_kf_ids:
            rvec = x[offset:offset + 3]
            offset += 3
            tvec = x[offset:offset + 3]
            offset += 3

            R_cw, _ = cv2.Rodrigues(rvec.reshape(3, 1))
            T_cw = np.eye(4, dtype=np.float64)
            T_cw[:3, :3] = R_cw
            T_cw[:3, 3] = tvec.reshape(3)
            pose_dict[kf_id] = T_cw

        for lm_id in lm_ids:
            pw = x[offset:offset + 3]
            offset += 3
            point_dict[lm_id] = pw.reshape(3)

        return pose_dict, point_dict

    def _residuals(
        self,
        x,
        observations,
        local_keyframes,
        landmarks,
        anchor_kf_id,
        opt_kf_ids,
        lm_ids,
    ):
        fx, fy, cx, cy = self.cam.fx, self.cam.fy, self.cam.cx, self.cam.cy

        pose_dict, point_dict = self._decode_parameters(
            x,
            local_keyframes,
            landmarks,
            anchor_kf_id,
            opt_kf_ids,
            lm_ids,
        )

        residuals = []

        for obs in observations:
            if obs.keyframe_id not in pose_dict:
                continue
            if obs.landmark_id not in point_dict:
                continue

            T_cw = pose_dict[obs.keyframe_id]
            pw = point_dict[obs.landmark_id]

            pc = T_cw[:3, :3] @ pw + T_cw[:3, 3]
            X, Y, Z = pc

            if Z <= 1e-6:
                residuals.extend([50.0, 50.0])
                continue

            u = fx * X / Z + cx
            v = fy * Y / Z + cy

            residuals.append(u - obs.uv[0])
            residuals.append(v - obs.uv[1])

        return np.asarray(residuals, dtype=np.float64)

    def _unpack_to_map(
        self,
        x,
        local_keyframes,
        landmarks,
        anchor_kf_id,
        opt_kf_ids,
        lm_ids,
    ):
        pose_dict, point_dict = self._decode_parameters(
            x,
            local_keyframes,
            landmarks,
            anchor_kf_id,
            opt_kf_ids,
            lm_ids,
        )

        kf_lookup = {int(kf.frame_idx): kf for kf in local_keyframes}

        for kf_id, T_cw in pose_dict.items():
            T_wc = np.linalg.inv(T_cw)
            kf_lookup[kf_id].pose_wc = T_wc

        for lm_id, pw in point_dict.items():
            landmarks[lm_id].position_w = np.asarray(pw, dtype=np.float64).reshape(3)